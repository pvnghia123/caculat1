//
//  calculation.h
//  calculib
//
//  Created by PVNghia on 1/29/21.
//

#ifndef calculation_h
#define calculation_h

#include <stdio.h>
float summation( float number1 , float number2);
float Subtraction( float number1 , float number2);
float multiplication( float number1 , float number2);
float division( float number1 , float number2);
float percentages( float number1);
#endif /* calculation_h */
