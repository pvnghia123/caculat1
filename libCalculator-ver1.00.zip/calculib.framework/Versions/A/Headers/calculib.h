//
//  calculib.h
//  calculib
//
//  Created by PVNghia on 1/29/21.
//

#import <Foundation/Foundation.h>
#import "calculation.h"

@interface calculib : NSObject

@end
