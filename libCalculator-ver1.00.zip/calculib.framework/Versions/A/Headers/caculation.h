//
//  caculation.h
//  libCaculator-SDK
//
//  Created by PVNghia on 1/28/21.
//

#ifndef caculation_h
#define caculation_h

#include <stdio.h>
float summation( float number1 , float number2);
float Subtraction( float number1 , float number2);
float multiplication( float number1 , float number2);
float division( float number1 , float number2);
float percentages( float number1);

#endif /* caculation_h */
